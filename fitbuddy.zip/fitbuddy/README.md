# FitBuddy – AI Fitness Plan Generator (Gemini + FastAPI)

Generates personalized 7-day workout plans and nutrition tips using Google's
Gemini models, with a FastAPI backend, SQLite storage, and a Jinja2 web UI.

The app **runs immediately even without a Gemini API key** (it shows clearly
labeled placeholder plans), so you can verify the whole flow first, then drop
in your key for real AI output.

## Project structure

```
fitbuddy/
├── requirements.txt
├── .env.example              # copy to .env and add your Gemini key
├── app/
│   ├── main.py                # FastAPI entry point
│   ├── routes.py              # all web + JSON API routes
│   ├── database.py            # SQLAlchemy models + SQLite helpers
│   ├── schemas.py             # Pydantic request models
│   ├── gemini_generator.py    # Gemini Pro -> workout plan
│   ├── gemini_flash_generator.py  # Gemini Flash -> nutrition tip
│   ├── updated_plan.py        # Gemini Pro -> feedback-based plan revision
│   ├── templates/
│   │   ├── index.html         # input form
│   │   ├── result.html        # plan + tip + feedback form
│   │   └── all_users.html     # admin dashboard
│   └── static/                # (put images/CSS here if you add any)
└── fitbuddy.db                # created automatically on first run
```

## 1. Open in VS Code

1. Unzip the project and open the `fitbuddy` folder in VS Code
   (`File → Open Folder...`).
2. Install the **Python** extension for VS Code if you don't already have it.

## 2. Set up the environment

Open a terminal in VS Code (`` Ctrl+` `` / `` Cmd+` ``) in the `fitbuddy` folder:

```bash
# Create and activate a virtual environment
python -m venv venv

# Windows
venv\Scripts\activate

# macOS / Linux
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

In VS Code, select this virtual environment as your Python interpreter:
`Ctrl+Shift+P` → "Python: Select Interpreter" → choose the one inside `venv`.

## 3. Add your Gemini API key

1. Get a free key at https://aistudio.google.com/app/apikey
2. Copy `.env.example` to a new file named `.env` in the project root.
3. Paste your key:

```
GOOGLE_API_KEY=your_real_key_here
```

(Without this step, the app still runs and returns clearly-labeled
placeholder plans/tips instead of AI-generated ones.)

## 4. Run the app

```bash
uvicorn app.main:app --reload
```

Then open:
- **App:** http://127.0.0.1:8000
- **Interactive API docs (Swagger):** http://127.0.0.1:8000/docs

## 5. Try it out

1. On the home page, fill in Name, User ID, Age, Weight, Fitness Goal, and
   Intensity, then click **Generate Plan**.
2. You'll see your 7-day workout plan and a nutrition tip.
3. Submit feedback (e.g. "more focus on cardio") — the plan will be revised
   and both versions are saved.
4. Visit **/view-all-users** (linked at the bottom of every page) to see the
   admin dashboard listing every user's original and updated plans, with a
   delete option.

You can also test the JSON API endpoints directly from `/docs`:
- `POST /api/generate-plan` — save a user + generate plan & tip (JSON body)
- `POST /api/generate-workout` — just generate a plan (JSON body)
- `GET /api/nutrition-tip?goal=...` — just generate a tip
- `POST /api/update-plan/{user_id}` — revise a plan via feedback (JSON body)
- `GET /api/users` — list all users and their plans as JSON

## 6. Notes / troubleshooting

- **"Error generating workout plan: 404 model not found"** — Google
  periodically renames/retires model versions. Open `.env` and set
  `GEMINI_PRO_MODEL` / `GEMINI_FLASH_MODEL` to a current model name (check
  https://ai.google.dev/gemini-api/docs/models for the latest list, e.g.
  `gemini-2.0-flash` or `gemini-1.5-pro`).
- **Database:** FitBuddy uses SQLite (`fitbuddy.db`), created automatically
  on first run in the project root. Delete this file to reset all data.
- **Changing the port:** `uvicorn app.main:app --reload --port 8080`
- **Deploying elsewhere later:** the app is stateless aside from
  `fitbuddy.db`, so it can be containerized or pointed at a different
  database URL in `app/database.py` for cloud deployment.
