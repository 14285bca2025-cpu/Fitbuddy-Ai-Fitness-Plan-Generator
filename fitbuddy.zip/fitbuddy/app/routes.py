"""
routes.py
---------
Core routing layer. Bridges the HTML templates, the Gemini AI generation
modules, and the SQLite database.

Web (HTML) routes:
    GET  /                    -> index.html (input form)
    POST /generate-workout    -> generates a plan, renders result.html
    POST /submit-feedback     -> revises a plan, renders result.html
    GET  /view-all-users      -> admin dashboard (all_users.html)
    POST /delete-user/{id}    -> deletes a user, redirects back to dashboard

JSON API routes (also explorable at /docs):
    POST /api/generate-workout
    GET  /api/nutrition-tip
    POST /api/generate-plan
    POST /api/update-plan/{user_id}
    GET  /api/users
"""

import os

from fastapi import APIRouter, Request, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates

from app.schemas import UserInput, FeedbackRequest, WorkoutRequest
from app.gemini_generator import generate_workout_gemini
from app.gemini_flash_generator import generate_nutrition_tip_with_flash
from app.updated_plan import update_workout_plan
from app.database import (
    save_user,
    save_plan,
    update_plan,
    get_original_plan,
    get_user,
    get_all_users_with_plans,
    get_plan_record,
    delete_user,
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TEMPLATE_DIR = os.path.join(BASE_DIR, "templates")
templates = Jinja2Templates(directory=TEMPLATE_DIR)

router = APIRouter()


# ---------------------------------------------------------------------------
# Web (HTML) routes
# ---------------------------------------------------------------------------

@router.get("/", response_class=HTMLResponse)
def home(request: Request):
    """Home route - displays the user input form."""
    return templates.TemplateResponse("index.html", {"request": request})


@router.post("/generate-workout", response_class=HTMLResponse)
def generate_workout(
    request: Request,
    username: str = Form(...),
    user_id: int = Form(...),
    age: int = Form(...),
    weight: float = Form(...),
    goal: str = Form(...),
    intensity: str = Form(...),
):
    """
    Receives the form submission from index.html, calls Gemini Pro for the
    workout plan and Gemini Flash for the nutrition tip, saves everything,
    and renders result.html.
    """
    save_user(
        user_id=user_id, name=username, age=age, weight=weight,
        goal=goal, intensity=intensity,
    )

    plan = generate_workout_gemini({"goal": goal, "intensity": intensity})
    nutrition_tip = generate_nutrition_tip_with_flash(goal)

    save_plan(user_id=user_id, plan=plan, nutrition_tip=nutrition_tip)

    return templates.TemplateResponse(
        "result.html",
        {
            "request": request,
            "username": username,
            "user_id": user_id,
            "age": age,
            "weight": weight,
            "goal": goal,
            "intensity": intensity,
            "workout_plan": plan,
            "nutrition_tip": nutrition_tip,
            "feedback_message": None,
        },
    )


@router.post("/submit-feedback", response_class=HTMLResponse)
def submit_feedback(
    request: Request,
    user_id: int = Form(...),
    feedback: str = Form(...),
):
    """
    Receives feedback from the feedback form on result.html, asks Gemini
    Pro to revise the original plan, stores it, and re-renders result.html.
    """
    user = get_user(user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found. Generate a plan first.")

    original = get_original_plan(user_id)
    if not original:
        raise HTTPException(status_code=404, detail="Original plan not found for this user.")

    updated = update_workout_plan(original, feedback)
    update_plan(user_id, updated)

    plan_record = get_plan_record(user_id)

    return templates.TemplateResponse(
        "result.html",
        {
            "request": request,
            "username": user.name,
            "user_id": user.id,
            "age": user.age,
            "weight": user.weight,
            "goal": user.goal,
            "intensity": user.intensity,
            "workout_plan": updated,
            "nutrition_tip": plan_record.nutrition_tip if plan_record else "",
            "feedback_message": "Your plan has been updated based on your feedback!",
        },
    )


@router.get("/view-all-users", response_class=HTMLResponse)
def view_all_users(request: Request):
    """Admin dashboard - lists every user and their original/updated plans."""
    users = get_all_users_with_plans()
    return templates.TemplateResponse("all_users.html", {"request": request, "users": users})


@router.post("/delete-user/{user_id}")
def delete_user_route(user_id: int):
    """Deletes a user (and their plan, via cascade) then redirects back."""
    deleted = delete_user(user_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="User not found.")
    return RedirectResponse(url="/view-all-users", status_code=303)


# ---------------------------------------------------------------------------
# JSON API routes (test these interactively at /docs)
# ---------------------------------------------------------------------------

@router.post("/api/generate-workout")
def api_generate_workout(request: WorkoutRequest):
    """Generate a workout plan via Gemini Pro, given JSON {goal, intensity}."""
    try:
        result = generate_workout_gemini({"goal": request.goal, "intensity": request.intensity})
        return {"model": "gemini-1.5-pro", "workout_plan": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/api/nutrition-tip")
def api_nutrition_tip(goal: str):
    """Generate a nutrition tip via Gemini Flash, given a `goal` query param."""
    tip = generate_nutrition_tip_with_flash(goal)
    return {"goal": goal, "nutrition_tip": tip}


@router.post("/api/generate-plan")
def api_generate_plan(user_data: UserInput):
    """Save a user's info and generate + save their workout plan + tip, all via JSON."""
    try:
        save_user(
            user_id=user_data.user_id,
            name=user_data.username,
            age=user_data.age,
            weight=user_data.weight,
            goal=user_data.goal,
            intensity=user_data.intensity,
        )
        plan = generate_workout_gemini({"goal": user_data.goal, "intensity": user_data.intensity})
        tip = generate_nutrition_tip_with_flash(user_data.goal)
        save_plan(user_data.user_id, plan, tip)
        return {
            "message": "Workout plan generated and saved successfully!",
            "workout_plan": plan,
            "nutrition_tip": tip,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Something went wrong: {e}")


@router.post("/api/update-plan/{user_id}")
def api_update_plan(user_id: int, data: FeedbackRequest):
    """Update a workout plan based on JSON feedback: {"feedback": "..."}."""
    original = get_original_plan(user_id)
    if not original:
        return {"error": "Original plan not found for this user."}
    updated = update_workout_plan(original, data.feedback)
    update_plan(user_id, updated)
    return {"updated_plan": updated}


@router.get("/api/users")
def api_get_all_users():
    """Returns all users and their plans as JSON (used by the admin dashboard's data)."""
    return get_all_users_with_plans()
