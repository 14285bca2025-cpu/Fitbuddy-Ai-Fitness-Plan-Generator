"""
schemas.py
----------
Pydantic models used to validate incoming JSON API requests.
(The HTML form endpoints use FastAPI's Form(...) parameters instead,
 which is why routes.py doesn't use these for the /generate-workout
 and /submit-feedback form-based routes.)
"""

from pydantic import BaseModel, Field


class UserInput(BaseModel):
    user_id: int
    username: str
    age: int = Field(..., gt=0, lt=120)
    weight: float = Field(..., gt=0)
    goal: str
    intensity: str  # "low", "medium", or "high"


class FeedbackRequest(BaseModel):
    feedback: str


class WorkoutRequest(BaseModel):
    goal: str
    intensity: str
