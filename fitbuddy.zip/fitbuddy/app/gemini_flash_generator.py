"""
gemini_flash_generator.py
--------------------------
Uses Google's Gemini Flash model (fast + lightweight) to generate a short
nutrition or recovery tip based on the user's fitness goal.
"""

import os
import google.generativeai as genai
from dotenv import load_dotenv

load_dotenv()

GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
MODEL_NAME = os.getenv("GEMINI_FLASH_MODEL", "gemini-1.5-flash-latest")

_model = None
if GOOGLE_API_KEY:
    genai.configure(api_key=GOOGLE_API_KEY)
    _model = genai.GenerativeModel(MODEL_NAME)


def generate_nutrition_tip_with_flash(goal: str) -> str:
    """
    Generate a nutrition or recovery tip using Gemini Flash based on the
    user's fitness goal.

    Args:
        goal (str): User's fitness goal, e.g. "weight loss", "muscle gain".

    Returns:
        str: Generated tip.
    """
    if not _model:
        return _fallback_tip(goal)

    prompt = (
        f"Give one clear, helpful nutrition or recovery tip for someone focused on '{goal}'. "
        "The tip should be practical, friendly, and easy to understand."
    )

    try:
        response = _model.generate_content(prompt)
        return response.text.strip()
    except Exception as e:
        return f"Error generating tip: {e}"


def _fallback_tip(goal: str) -> str:
    return (
        f"[No GOOGLE_API_KEY configured] For your goal of '{goal}', prioritize protein, "
        "stay hydrated, and get enough sleep to support recovery."
    )
