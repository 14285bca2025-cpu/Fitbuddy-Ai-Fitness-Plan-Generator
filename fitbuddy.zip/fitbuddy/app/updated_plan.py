"""
updated_plan.py
----------------
Takes a user's original workout plan plus their feedback, and asks Gemini
Pro to revise the plan accordingly.
"""

import os
import google.generativeai as genai
from dotenv import load_dotenv

load_dotenv()

GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
MODEL_NAME = os.getenv("GEMINI_PRO_MODEL", "gemini-1.5-pro-latest")

_model = None
if GOOGLE_API_KEY:
    genai.configure(api_key=GOOGLE_API_KEY)
    _model = genai.GenerativeModel(MODEL_NAME)


def update_workout_plan(original_plan: str, user_feedback: str) -> str:
    """
    Use Gemini Pro to update the workout plan based on user feedback.
    """
    if not _model:
        return (
            original_plan
            + f"\n\n[No GOOGLE_API_KEY configured - feedback received but not applied: "
            f"'{user_feedback}']"
        )

    prompt = f"""
    You are a professional fitness trainer assistant.

    Here's the original 7-day workout plan:
    {original_plan}

    User Feedback:
    "{user_feedback}"

    Based on the feedback, revise the relevant parts of the workout plan. Keep the format and
    rest of the plan unchanged if not needed.
    """
    try:
        response = _model.generate_content(prompt)
        return response.text.strip()
    except Exception as e:
        return f"Error updating plan: {e}"
