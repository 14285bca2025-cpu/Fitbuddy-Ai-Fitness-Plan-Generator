"""
gemini_generator.py
--------------------
Uses Google's Gemini Pro model to generate a structured 7-day workout plan.
"""

import os
import google.generativeai as genai
from dotenv import load_dotenv

load_dotenv()

GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
MODEL_NAME = os.getenv("GEMINI_PRO_MODEL", "gemini-1.5-pro-latest")

_model = None
if GOOGLE_API_KEY:
    genai.configure(api_key=GOOGLE_API_KEY)
    _model = genai.GenerativeModel(MODEL_NAME)


def generate_workout_gemini(user_input: dict) -> str:
    """
    Generate a personalized 7-day workout plan.

    Args:
        user_input (dict): expects keys "goal" and "intensity".

    Returns:
        str: the generated (or fallback) workout plan text.
    """
    goal = user_input.get("goal", "general fitness")
    intensity = user_input.get("intensity", "medium")

    if not _model:
        return _fallback_plan(goal, intensity)

    prompt = f"""
    You are a professional fitness trainer.

    Create a personalized, structured 7-day workout plan for someone with the goal of
    **{goal}**, and prefers **{intensity} intensity** workouts.

    Each day must include:
    - A warm-up (5-10 mins)
    - Main workout (targeted exercises, sets & reps)
    - Cooldown or recovery tip

    Format:
    Day 1:
    Warm-up: ...
    Main Workout: ...
    Cooldown: ...
    (Repeat for Day 2-7)
    """
    try:
        response = _model.generate_content(prompt)
        return response.text
    except Exception as e:
        return f"Error generating workout plan: {e}"


def _fallback_plan(goal: str, intensity: str) -> str:
    """Used when no GOOGLE_API_KEY is configured, so the app still runs end-to-end."""
    return (
        "[No GOOGLE_API_KEY configured - showing a placeholder plan]\n\n"
        f"Goal: {goal} | Intensity: {intensity}\n\n"
        "Day 1:\n"
        "Warm-up: 5-10 min light cardio + dynamic stretches\n"
        "Main Workout: Full-body strength circuit - 3 sets x 10-12 reps "
        "(squats, push-ups, rows, lunges)\n"
        "Cooldown: 5 min static stretching\n\n"
        "(Repeat similar structure, varying muscle groups and intensity, for Days 2-7.)\n\n"
        "Add a real Gemini API key to your .env file to get fully AI-generated, "
        "goal-specific plans."
    )
