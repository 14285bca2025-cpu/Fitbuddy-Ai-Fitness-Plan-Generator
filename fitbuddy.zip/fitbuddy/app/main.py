"""
main.py
-------
FastAPI application entry point for FitBuddy.

Run with:
    uvicorn app.main:app --reload

Then visit:
    http://127.0.0.1:8000        -> the app
    http://127.0.0.1:8000/docs   -> interactive API docs
"""

import os

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from dotenv import load_dotenv

from app.database import init_db
from app.routes import router

load_dotenv()

app = FastAPI(
    title="FitBuddy - AI Fitness Plan Generator",
    description="Generates personalized 7-day workout plans and nutrition tips using Gemini AI.",
    version="1.0.0",
)

# Serve /static (e.g. background images, if you add any) from app/static
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(BASE_DIR, "static")
os.makedirs(STATIC_DIR, exist_ok=True)
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

# Create database tables on startup (safe to call every time - no-op if they exist)
init_db()

# Register all routes
app.include_router(router)
